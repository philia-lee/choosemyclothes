let vue = new vue({
    el : "#vueEx",
    data : {
        abc : '123123'
    }
})